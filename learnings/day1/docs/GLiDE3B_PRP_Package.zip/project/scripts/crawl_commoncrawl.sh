#!/usr/bin/env bash
set -euo pipefail
echo "Download WET paths and iterate them here..."

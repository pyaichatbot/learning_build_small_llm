# Export 4-bit GGUF + vLLM compatible weights

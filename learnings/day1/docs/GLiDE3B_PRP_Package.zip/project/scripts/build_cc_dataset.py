# Outline: stream WET/WARC -> extract -> filter -> dedup -> shard

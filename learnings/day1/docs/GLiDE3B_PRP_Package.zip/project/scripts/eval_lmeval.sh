#!/usr/bin/env bash
set -euo pipefail
python -m lm_eval --model hf \
  --model_args pretrained=./artifacts/ckpt,trust_remote_code=true,use_accelerate=true \
  --tasks mmlu,hellaswag,arc_challenge,truthfulqa_mc1,winogrande,gsm8k \
  --device cuda --batch_size 8 --num_fewshot 5 \
  --output_path eval/results.json

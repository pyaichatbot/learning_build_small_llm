# Trainer entrypoint wiring configs to HF Transformers + DeepSpeed

# Train SentencePiece BPE (50k) from cleaned corpus shards

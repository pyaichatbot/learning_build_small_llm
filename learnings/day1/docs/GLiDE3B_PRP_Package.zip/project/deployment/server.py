# Simple vLLM server wrapper

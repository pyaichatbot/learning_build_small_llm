# FlashAttention-2 hooks where supported

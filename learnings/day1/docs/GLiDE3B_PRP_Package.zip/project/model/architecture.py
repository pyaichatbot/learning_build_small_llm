# Define 3B architecture config and build HF model from config

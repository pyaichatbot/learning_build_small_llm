# Generation helper with paged KV cache

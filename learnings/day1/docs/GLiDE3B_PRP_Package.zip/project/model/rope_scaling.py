# YaRN/NTK-aware RoPE scaling utilities

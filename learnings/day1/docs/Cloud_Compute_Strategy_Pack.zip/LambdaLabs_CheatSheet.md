# ⚡ Lambda Labs Setup Cheat Sheet

### 1. Instance Selection
- Choose **RTX A6000 (48 GB)** for 3B–7B models
- Or **A100 40 GB** for heavier fine-tuning
- Cost: ~$1.10–$1.29/hr (pay-as-you-go)

### 2. Basic Setup Commands
```bash
# SSH into instance
ssh ubuntu@<ip>

# Check GPU
nvidia-smi

# Create env
conda create -n llm python=3.10 -y
conda activate llm

# Install stack
pip install torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu124
pip install transformers datasets peft accelerate bitsandbytes deepspeed wandb sentencepiece vllm gradio

# Login to HF
huggingface-cli login

# Launch Jupyter
jupyter lab --ip=0.0.0.0 --no-browser --port=8888
```

### 3. Cost Monitoring
- Stop instance when idle (`sudo shutdown now`)
- Use snapshots for dataset reuse
- Track active hours in Lambda dashboard
